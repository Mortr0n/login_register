from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages
from .models import *

def index(request):
    context = {
        
    }
    
    return render (request, 'index.html', context)

def register(request):
    if request.method != 'POST':
        return redirect('/')
    errors = User.objects.User_Manager(request.POST)
    
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/success')
    else:
        new_user = User.objects.create(first_name=request.POST['first_name'],
                                        last_name=request.POST['last_name'],
                                        email=request.POST['email'],
                                        password=request.POST['password'],)
        messages.success(request, 'User Created')
        return redirect('success')

def success(request):
    context = {
        
    }
    return render (request, 'success.html', context)

def login(request):
    pass

def logout(request):
    pass